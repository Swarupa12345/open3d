DRDL Open3D Live Generation Update v3.4.1
OFFLINE WINDOWS SETUP AND RUN COMMANDS
======================================

PURPOSE
-------
This README explains how to run the DRDL project on a Windows PC without
internet access. It assumes you have already copied the project ZIP and
extracted it into a folder.

IMPORTANT
---------
The main GUI and the Open3D viewer may use DIFFERENT Python interpreters.
On the computer where this project was last checked, the main GUI used
Python 3.8.10 at:
  C:\Users\user\AppData\Local\Programs\Python\Python38\python.exe

Open3D 0.18.0 was found in this separate environment:
  C:\Users\user\Downloads\files16_matplotlib\open3d_test_env\Scripts\python.exe

Those exact paths only work if those folders exist on THIS computer. If you
are setting up a different offline PC, use the actual paths on that PC.
A Python virtual environment is not reliably portable by copying its folder;
for a different PC, follow the section "IF THIS IS A DIFFERENT OFFLINE PC".

PART A — RUN ON THE SAME COMPUTER WHERE OPEN3D ALREADY WORKS
------------------------------------------------------------
1. Extract the project ZIP into a new folder, for example:
   C:\Users\user\Downloads\DRDL_Open3D_Live_Generation_Update_v3_4_1

2. Open File Explorer and open that extracted folder. Confirm that app.py is
   visible. Click the address bar, type cmd, and press Enter.

3. Check the main Python version:
   python --version

   Expected for this project:
   Python 3.8.10

4. Tell this CMD window where the Open3D interpreter is:
   set "OPEN3D_PYTHON=C:\Users\user\Downloads\files16_matplotlib\open3d_test_env\Scripts\python.exe"

   IMPORTANT: Run this command and the later commands in the SAME CMD window.
   The SET command only lasts for that CMD window.

5. Verify that Open3D works in that interpreter:
   "%OPEN3D_PYTHON%" -c "import sys, open3d as o3d; print(sys.executable); print(o3d.__version__)"

   Expected version:
   0.18.0

6. Check the project files for Python syntax errors:
   python -m py_compile app.py open3d_viewer.py optimizer.py predictor.py envelope.py aero_body_vis.py

   If there is no error text and CMD returns to the prompt, continue.

7. Start the GUI:
   python app.py

8. Click VISUALIZE in the Prediction tab. A separate Open3D window should
   open. Then test Optimization and Flight Envelope.

9. For live generation viewing, open the Optimization tab and start the
   optimizer. The separate viewer should receive actual generation updates.
   To see the optional illustrative internal structure, focus the Open3D
   window and press I. Press I again to return to the exterior.

PART B — IF THE SAME COMPUTER DOES NOT HAVE THAT OPEN3D PATH
-----------------------------------------------------------
1. Check whether the environment exists:
   dir "C:\Users\user\Downloads\files16_matplotlib\open3d_test_env\Scripts\python.exe"

2. If Windows says the file cannot be found, do not keep using that path.
   Find the location of the working open3d_test_env folder or follow Part C
   to install dependencies from an offline wheel folder.

PART C — IF THIS IS A DIFFERENT OFFLINE PC
------------------------------------------
An offline PC cannot download packages from the internet. Prepare these items
on a computer with internet access and copy them to the offline PC by USB:

  A. The full DRDL project ZIP.
  B. A folder named offline_wheels containing the Python wheel files needed
     for the project, including Open3D and all required dependencies.
  C. Confirm that the wheels match the offline PC's Python version, Windows
     version, and 64-bit/32-bit architecture.

Do not assume that the Open3D wheel alone contains all dependencies. The app
also needs its own GUI, plotting, numerical, and ML dependencies. If these
packages are already installed on the offline PC, you may not need to install
them again.

After copying the files and extracting the project, open CMD in the project
folder and create a new environment (if Python 3.8 is installed):

  python -m venv drdl_env
  drdl_env\Scripts\python.exe -m pip install --no-index --find-links=offline_wheels -r requirements.txt

NOTE: Use the command above only if a complete, compatible requirements.txt
and all required wheel files are present. The supplied project ZIP may not
include a complete requirements.txt or offline wheelhouse. If either is
missing, do not run this command expecting it to work; collect the required
wheel files and dependency list on an internet-connected computer first.

If the Open3D environment is separate, install the compatible Open3D wheel
and its dependencies into the interpreter intended for the viewer. Example
for a wheelhouse that contains all required compatible wheels:

  drdl_env\Scripts\python.exe -m pip install --no-index --find-links=offline_wheels open3d==0.18.0
  drdl_env\Scripts\python.exe -c "import open3d as o3d; print(o3d.__version__)"

The Open3D 0.18.0 wheel is not supported on every older Windows version.
Check OS compatibility before relying on it; a successful package install
alone does not prove that the native viewer can run.

If the main GUI environment is named drdl_env, set the viewer interpreter:
  set "OPEN3D_PYTHON=%CD%\drdl_env\Scripts\python.exe"

Then run the syntax check and GUI launch from Part A, steps 6 and 7.

TROUBLESHOOTING
---------------
A. If the GUI says it cannot find a Python interpreter with Open3D installed:
   Run:
   "%OPEN3D_PYTHON%" -c "import open3d as o3d; print(o3d.__version__)"
   If this fails, OPEN3D_PYTHON points to the wrong interpreter or Open3D
   cannot import in that environment.

B. Do NOT run open3d_viewer.py by itself with no arguments. This viewer needs
   a parameter file supplied by the GUI, so it will report that --params-file
   is required when run alone. That message does not prove the viewer is broken.

C. If VISUALIZE still does not open a window, inspect the viewer log files
   under the project's open3d_sessions folder, if that folder exists. Copy
   the complete relevant log and any CMD error output for diagnosis.

D. If the window opens but is black, report that separately and include the
   viewer log. Do not change predictor.py, optimizer.py, or envelope.py while
   diagnosing a viewer-launch issue.

E. If MP4 recording fails, the viewer environment may need a compatible
   opencv-python installation. For offline installation, its wheel and all
   required dependencies must also be copied to offline_wheels.

NOTES
-----
- Keep a backup of the original project ZIP and folder.
- Do not extract new versions over a working project folder.
- Internal ribs, frames, stringers, and spars are illustrative visualization
  aids unless validated structural data is supplied. They do not change the
  aerodynamic calculations.
- The commands above are a setup guide. A different offline PC may require
  different paths and additional dependency wheels.
